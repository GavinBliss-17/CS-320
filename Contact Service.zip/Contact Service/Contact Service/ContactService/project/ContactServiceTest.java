import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ContactServiceTest {
    private ContactService service;

    @Before
    public void setUp() {
        service = new ContactService();
    }

    // Test adding a valid contact
    @Test
    public void testAddContact() {
        Contact contact = new Contact("ID123456", "Mike", "Tyson", "1234567890", "123 MSG St");
        service.addContact(contact);
        assertNotNull(service.getContact("ID123456")); // Verify that the contact was added
    }

    // Test adding a duplicate contact, expecting an IllegalArgumentException
    @Test(expected = IllegalArgumentException.class)
    public void testAddDuplicateContact() {
        Contact contact = new Contact("ID123456", "Mike", "Tyson", "1234567890", "123 MSG St");
        service.addContact(contact);
        service.addContact(contact); // This should throw an exception
    }

    // Test updating an existing contact
    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("ID123456", "Mike", "Tyson", "1234567890", "123 MSG St");
        service.addContact(contact);
        service.updateContact("ID123456", "Muhammad", "Ali", "0987654321", "456 MSG St");
        Contact updatedContact = service.getContact("ID123456");
        assertEquals("Muhammad", updatedContact.getFirstName());
        assertEquals("Ali", updatedContact.getLastName());
        assertEquals("0987654321", updatedContact.getPhoneNumber()); // Corrected method name to getPhoneNumber
        assertEquals("456 MSG St", updatedContact.getAddress());
    }

    // Test deleting a contact that does not exist, expecting an IllegalArgumentException
    @Test(expected = IllegalArgumentException.class)
    public void testDeleteNonexistentContact() {
        service.deleteContact("NonexistentID"); // This should throw an exception
    }
}
