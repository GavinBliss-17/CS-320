import static org.junit.Assert.*;
import org.junit.Test;

public class ContactTest {

    @Test
    public void testContactCreationSuccess() {
        Contact contact = new Contact("ID123456", "Mike", "Tyson", "1234567890", "123 MSG St");
        assertNotNull(contact);
        assertEquals("ID123456", contact.getContactID());
        assertEquals("Mike", contact.getFirstName());
        assertEquals("Tyson", contact.getLastName());
        // Corrected method name to match the actual getter method in the Contact class
        assertEquals("1234567890", contact.getPhoneNumber());
        assertEquals("123 MSG St", contact.getAddress());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testContactIDTooLong() {
        new Contact("ID12345678901", "Mike", "Tyson", "1234567890", "123 MSG St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFirstNameTooLong() {
        // Corrected the test to actually check for a long first name instead of repeating the previous test
        new Contact("ID123456", "Mikeeeeeeeee", "Tyson", "1234567890", "123 MSG St");
    }

    // Additional tests to validate the constraints for lastName, phoneNumber, and address fields
    @Test(expected = IllegalArgumentException.class)
    public void testLastNameTooLong() {
        new Contact("ID123456", "Mike", "Tysonnnnnnnnnn", "1234567890", "123 MSG St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPhoneNumberNotTenDigits() {
        new Contact("ID123456", "Mike", "Tyson", "12345", "123 MSG St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidPhoneNumber() {
        new Contact("ID123456", "Mike", "Tyson", "abcdefghij", "123 MSG St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddressTooLong() {
        new Contact("ID123456", "Mike", "Tyson", "1234567890", "123 Main Street, Springfield, Anywhere, USA, 12345");
    }
}
