import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    // Adds a new contact to the contacts map
    public void addContact(Contact contact) {
        if (contact == null || contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact cannot be added or already exists");
        }
        contacts.put(contact.getContactID(), contact);
    }

    // Deletes a contact by its ID
    public void deleteContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact does not exist");
        }
        contacts.remove(contactID);
    }

    // Updates the specified fields of an existing contact
    public void updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact does not exist");
        }
        if (firstName != null && !firstName.isBlank()) contact.setFirstName(firstName);
        if (lastName != null && !lastName.isBlank()) contact.setLastName(lastName);
        if (phoneNumber != null && !phoneNumber.isBlank()) contact.setPhoneNumber(phoneNumber);
        if (address != null && !address.isBlank()) contact.setAddress(address);
    }
    
    // Retrieves a contact by its ID
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }
}
